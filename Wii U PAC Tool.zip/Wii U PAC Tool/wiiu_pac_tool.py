import os
import re
import shutil
import struct
import subprocess
import sys
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))

USAGE = """Wii U PAC tool

  wiiu_pac_tool.py file.bin [file2.bin ...]
      Extracts the raw files (.gtx, .bnfm, .bnfmsa, .mcf, ...)
  wiiu_pac_tool.py --convert file.bin [file2.bin ...]
      Also converts textures to PNG and models to OBJ
"""


def u32(data, offset):
    return struct.unpack(">I", data[offset:offset + 4])[0]


def cstr(data, offset):
    return data[offset:data.index(b"\0", offset)].decode("ascii", "replace")


def extract_pac(path, outdir):
    data = open(path, "rb").read()
    if data[:4] != b"PAC\0":
        raise ValueError("not a PAC container (header %r)" % data[:4])
    count = u32(data, 0x20)
    table = u32(data, 0x38)
    files = []
    for i in range(count):
        w = struct.unpack(">12I", data[table + i * 0x30:table + (i + 1) * 0x30])
        name = cstr(data, w[0])
        offset, size = w[4], w[6]
        blob = data[offset:offset + size]
        try:
            blob = zlib.decompress(blob)
        except zlib.error:
            print("  warning: %s is not zlib data, saved as is" % name)
        rel = name.replace("\\", "/").lstrip("/")
        target = os.path.join(outdir, *rel.split("/"))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        open(target, "wb").write(blob)
        files.append(target)
        print("  [%2d/%d] %s (%d bytes)" % (i + 1, count, rel, len(blob)))
    return files


def convert_gtx(gtx, outdir):
    from PIL import Image
    os.makedirs(outdir, exist_ok=True)
    base = os.path.splitext(os.path.basename(gtx))[0]
    dds_path = os.path.join(outdir, base + ".dds")
    result = subprocess.run(
        [sys.executable, os.path.join(HERE, "gtx_extract.py"), "-o", dds_path, gtx],
        capture_output=True, text=True, cwd=HERE)
    if not os.path.exists(dds_path):
        print("  texture %s FAILED: %s" % (base, (result.stderr or result.stdout).strip()[-200:]))
        return None
    try:
        image = Image.open(dds_path)
        image.load()
        png = os.path.join(outdir, base + ".png")
        image.save(png)
        print("  texture %s -> %dx%d" % (base, image.size[0], image.size[1]))
        return png
    except Exception as error:
        print("  texture %s: DDS created but PNG conversion failed (%s)" % (base, error))
        return dds_path


def half(raw):
    h = struct.unpack(">H", raw)[0]
    sign = -1.0 if h & 0x8000 else 1.0
    exp = (h >> 10) & 0x1F
    mant = h & 0x3FF
    if exp == 0:
        return sign * (mant / 1024.0) * 2 ** -14
    if exp == 31:
        return 0.0
    return sign * (1 + mant / 1024.0) * 2 ** (exp - 15)


def convert_bnfm(path, obj_path, texture=None):
    data = open(path, "rb").read()
    if data[:2] != b"WU":
        raise ValueError("unexpected header %r" % data[:4])
    index_start = u32(data, 0x0C)
    index_size = u32(data, 0x10)
    vertex_size = u32(data, 0x14)
    mesh_count = u32(data, 0x2C)
    mesh_table = u32(data, 0x5C)
    if index_start + index_size + vertex_size != len(data):
        print("  warning: section sizes do not match the file size, result may be wrong")
    meshes = []
    for i in range(mesh_count):
        w = struct.unpack(">12I", data[mesh_table + i * 0x30:mesh_table + (i + 1) * 0x30])
        name = re.sub(r"[^A-Za-z0-9_]+", "_", cstr(data, w[0])).strip("_") or "mesh%d" % i
        meshes.append((name, w[6], w[7]))
    total_indices = sum(m[1] for m in meshes)
    total_vertices = sum(m[2] for m in meshes)
    if total_vertices == 0:
        raise ValueError("no vertices")
    stride = vertex_size // total_vertices
    padding = vertex_size - stride * total_vertices
    if not (0 <= padding <= 16) or stride < 12:
        raise ValueError("cannot infer vertex size (stride=%d, remainder=%d)" % (stride, padding))
    if stride != 44:
        print("  warning: vertex stride is %d (44 expected), UVs and normals may be wrong" % stride)
    index_block = data[index_start:index_start + index_size]
    vertex_block = data[index_start + index_size:]
    indices = struct.unpack(">%dH" % (len(index_block) // 2), index_block)
    mtl_name = os.path.splitext(os.path.basename(obj_path))[0] + ".mtl"
    lines = ["# Extracted from %s" % os.path.basename(path), "mtllib %s" % mtl_name]
    index_offset = 0
    vertex_offset = 0
    base = 1
    suspicious = False
    for name, index_count, vertex_count in meshes:
        part = indices[index_offset:index_offset + index_count]
        index_offset += index_count
        if part and max(part) >= vertex_count:
            print("  warning: mesh %s has out-of-range indices" % name)
            suspicious = True
        lines += ["o " + name, "usemtl body"]
        positions, uvs, normals = [], [], []
        for k in range(vertex_count):
            row = vertex_block[(vertex_offset + k) * stride:(vertex_offset + k + 1) * stride]
            positions.append(struct.unpack(">3f", row[0:12]))
            if stride >= 0x18:
                uvs.append((half(row[0x14:0x16]), 1 - half(row[0x16:0x18])))
            else:
                uvs.append((0.0, 0.0))
            normals.append([max(-1.0, x / 127.0) for x in struct.unpack(">3b", row[12:15])])
        vertex_offset += vertex_count
        if any(not all(abs(c) < 1e5 and c == c for c in p) for p in positions):
            print("  warning: mesh %s has absurd positions" % name)
            suspicious = True
        lines += ["v %.6f %.6f %.6f" % p for p in positions]
        lines += ["vt %.6f %.6f" % t for t in uvs]
        lines += ["vn %.5f %.5f %.5f" % tuple(n) for n in normals]
        for k in range(0, len(part) - len(part) % 3, 3):
            a, b, c = (base + i for i in part[k:k + 3])
            lines.append("f %d/%d/%d %d/%d/%d %d/%d/%d" % (a, a, a, b, b, b, c, c, c))
        base += vertex_count
    open(obj_path, "w").write("\n".join(lines) + "\n")
    with open(os.path.splitext(obj_path)[0] + ".mtl", "w") as mtl:
        mtl.write("newmtl body\nKd 1 1 1\n")
        if texture:
            mtl.write("map_Kd %s\n" % os.path.basename(texture))
    print("  model %s -> %d meshes (%s), %d vertices, %d triangles%s" % (
        os.path.basename(path), len(meshes), ", ".join(m[0] for m in meshes),
        total_vertices, total_indices // 3, "  [CHECK]" if suspicious else ""))


def pick_texture(pngs):
    candidates = [p for p in pngs if p and p.lower().endswith(".png")]
    preferred = [p for p in candidates if os.path.basename(p).lower().endswith("_body.png")]
    plain = [p for p in candidates if not re.search(r"_(ref|spe|nor|msk)\.png$", p.lower())]
    for group in (preferred, plain, candidates):
        if group:
            return group[0]
    return None


def process(path, convert=False):
    path = os.path.abspath(path)
    print("\n== %s" % path)
    out = os.path.splitext(path)[0] + "_extracted"
    os.makedirs(out, exist_ok=True)
    with open(path, "rb") as handle:
        head = handle.read(4)
    if head != b"PAC\0":
        print("  not a PAC container (header %r), nothing to do" % head)
        return
    files = extract_pac(path, out)
    if not convert:
        print("  Done (raw files) -> %s" % out)
        return
    gtx_files = [p for p in files if p.lower().endswith(".gtx")]
    bnfm_files = [p for p in files if p.lower().endswith(".bnfm")]
    pngs = [convert_gtx(g, os.path.join(out, "textures")) for g in gtx_files]
    model_dir = os.path.join(out, "models")
    for bnfm in bnfm_files:
        os.makedirs(model_dir, exist_ok=True)
        texture = pick_texture(pngs)
        if texture:
            shutil.copy(texture, model_dir)
            texture = os.path.join(model_dir, os.path.basename(texture))
        try:
            obj = os.path.join(model_dir, os.path.splitext(os.path.basename(bnfm))[0] + ".obj")
            convert_bnfm(bnfm, obj, texture)
        except Exception as error:
            print("  model %s FAILED: %s" % (os.path.basename(bnfm), error))
    others = [p for p in files if p.lower().endswith((".bnfmsa", ".mcf"))]
    if others:
        print("  (extracted only, not converted: %d .bnfmsa/.mcf files)" % len(others))
    print("  Done -> %s" % out)


def main():
    args = sys.argv[1:]
    convert = "--convert" in args
    args = [a for a in args if a != "--convert"]
    if not args:
        try:
            import tkinter
            from tkinter import filedialog
            tkinter.Tk().withdraw()
            args = list(filedialog.askopenfilenames(
                title="Select .bin files", filetypes=[("BIN", "*.bin"), ("All files", "*.*")]))
        except Exception:
            print(USAGE)
            return
    for arg in args:
        try:
            process(arg, convert)
        except Exception as error:
            print("  ERROR: %s" % error)
    if sys.stdin and sys.stdin.isatty():
        input("\nPress Enter to close...")


if __name__ == "__main__":
    main()
