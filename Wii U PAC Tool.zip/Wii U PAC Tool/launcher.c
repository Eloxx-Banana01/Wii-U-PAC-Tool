#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef CONVERT
#define MODE_FLAG " --convert"
#else
#define MODE_FLAG ""
#endif

static int run(const char *command)
{
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    DWORD code = 1;
    char *buffer = _strdup(command);
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    if (!buffer)
        return 1;
    if (!CreateProcessA(NULL, buffer, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi)) {
        free(buffer);
        return 9009;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    free(buffer);
    return (int)code;
}

static void append_quoted(char *dest, size_t size, const char *arg)
{
    size_t len = strlen(dest);
    size_t backslashes = 0;
    if (len + 3 >= size)
        return;
    dest[len++] = ' ';
    dest[len++] = '"';
    for (; *arg && len + 4 < size; arg++) {
        if (*arg == '\\') {
            backslashes++;
            dest[len++] = *arg;
        } else if (*arg == '"') {
            while (backslashes--)
                dest[len++] = '\\';
            dest[len++] = '\\';
            dest[len++] = '"';
            backslashes = 0;
        } else {
            backslashes = 0;
            dest[len++] = *arg;
        }
    }
    while (backslashes--)
        dest[len++] = '\\';
    dest[len++] = '"';
    dest[len] = 0;
}

static void wait_for_enter(void)
{
    printf("\nPress Enter to close...");
    fflush(stdout);
    getchar();
}

int main(int argc, char **argv)
{
    char dir[MAX_PATH];
    char script[MAX_PATH + 32];
    char command[32768];
    const char *python = NULL;
    DWORD length = GetModuleFileNameA(NULL, dir, MAX_PATH);
    int i;

    while (length > 0 && dir[length - 1] != '\\')
        length--;
    dir[length] = 0;
    snprintf(script, sizeof(script), "%swiiu_pac_tool.py", dir);

    if (run("cmd /c py -3 --version >nul 2>nul") == 0)
        python = "py -3";
    else if (run("cmd /c python --version >nul 2>nul") == 0)
        python = "python";

    if (!python) {
        printf("Python 3 was not found.\n");
        printf("Install it from https://www.python.org/downloads/ and tick \"Add Python to PATH\".\n");
        wait_for_enter();
        return 1;
    }

#ifdef CONVERT
    snprintf(command, sizeof(command), "%s -c \"import PIL\"", python);
    if (run(command) != 0) {
        printf("Installing Pillow (one time only)...\n");
        snprintf(command, sizeof(command), "%s -m pip install pillow", python);
        if (run(command) != 0) {
            printf("Could not install Pillow.\n");
            wait_for_enter();
            return 1;
        }
    }
#endif

    snprintf(command, sizeof(command), "%s", python);
    append_quoted(command, sizeof(command), script);
    strncat(command, MODE_FLAG, sizeof(command) - strlen(command) - 1);
    for (i = 1; i < argc; i++)
        append_quoted(command, sizeof(command), argv[i]);
    return run(command);
}
